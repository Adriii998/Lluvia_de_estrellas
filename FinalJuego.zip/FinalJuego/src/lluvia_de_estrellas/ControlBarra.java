package lluvia_de_estrellas;

import java.awt.Rectangle;
import java.awt.event.KeyEvent;

public class ControlBarra{
    
    private Bar barra;
    private Game game;

    public ControlBarra(Game juego,Vista1 vista){
        barra=new Bar(); // Creamos la barra desde el Controlador de BARRA
        this.game=juego;
        game.actualizarPosBarra(barra.getBounds());
        
        vista.anadirPanel(barra.getBarra(), barra.getDivisoria()); // Añadimos ambas barras a la vista
        
    }
    
    public void recibirTecla(int codigo){

        if (codigo==KeyEvent.VK_RIGHT){ // Si el código es la flecha derecha nos movemos a la derecha
            barra.moverDerecha();
        }

        if (codigo==KeyEvent.VK_LEFT){ // Si el código es la flecha izquierda nos movemos a la izquierda
            barra.moverIzquierda();
        }
        
        game.actualizarPosBarra(barra.getBounds()); // Actualizamos la pos. de la barra con las dimensiones ya cambiadas de su propia clase
    }
    
    public Rectangle getLimite(){
        return barra.getLimite();
    }
    
}
