package lluvia_de_estrellas;

public class Lluvia_de_estrellas {

    public static void main(String[] args) {
        Game juego=new Game();
    }
    
}
