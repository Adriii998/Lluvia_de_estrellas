package lluvia_de_estrellas;


public class Niveles {
    
    private final String LEVEL1="ASDÑLK";
    private final int CAIDA1=75;
    private final String LEVEL2="ASDFÑLKJ";
    private final int CAIDA2=50;
    private final String LEVEL3="ASDFGÑLKJH";
    private final int CAIDA3=25;
    private final String LEVEL4="ASDWXÑLKOM";
    private final int CAIDA4=15;
    private final String LEVEL5="QWEASDZXCPOIÑLKMNB";
    private final int CAIDA5=5;
    
    
    public Niveles(){
        
    }

    public String getLEVEL1() {
        return LEVEL1;
    }

    public int getCAIDA1() {
        return CAIDA1;
    }

    public String getLEVEL2() {
        return LEVEL2;
    }

    public int getCAIDA2() {
        return CAIDA2;
    }

    public String getLEVEL3() {
        return LEVEL3;
    }

    public int getCAIDA3() {
        return CAIDA3;
    }

    public String getLEVEL4() {
        return LEVEL4;
    }

    public int getCAIDA4() {
        return CAIDA4;
    }

    public String getLEVEL5() {
        return LEVEL5;
    }

    public int getCAIDA5() {
        return CAIDA5;
    }
    
    
    
    
}
