package lluvia_de_estrellas;

import java.awt.Color;
import java.awt.Rectangle;
import java.io.Serializable;
import javax.swing.JPanel;


public class Bar implements Serializable{
    private int xBarra = 100; // Situamos la barra en eje X
    private int yBarra = 475 ; // Situamos la barra en eje Y
    private int anchoBarra = 100; // Le damos un ancho para poder cambiarlo fácilmente en caso de ser necesario en el futuro

    private JPanel barra;
    private JPanel divisoria;

    public Bar() {
        crearBarra(); // Creamos la barra que podremos mover
        crearDivisoria(); // Creamos la línea divisoria, que viene a ser nuestro GAME OVER si alguna letra colisiona con ella
    }
    
    public void crearBarra(){
        barra=new JPanel(); // La barra va a ser un JPanel
        barra.setBounds(xBarra, yBarra, anchoBarra, 10); // Dimensiones correspondientes para situarla
        barra.setBackground(Color.BLUE);  // Color a la barra
    }
    
    public void crearDivisoria(){
        divisoria=new JPanel();
        divisoria.setBounds(0, 500, 800, 3);
        divisoria.setBackground(Color.BLACK);
    }

    public JPanel getBarra() {
        return barra;
    }

    public JPanel getDivisoria() {
        return divisoria;
    }


    public void moverIzquierda() {
        if (xBarra>=10) { // Podemos moverla hasta el extremo izquierdo
            xBarra -= 10;
            barra.setLocation(xBarra, yBarra);
        }
    }

    public void moverDerecha() {
        if (xBarra<=690) {  // Podemos moverla hasta el extremo derecho siempre que no haya llegado al final del mismo
            xBarra += 10;
            barra.setLocation(xBarra, yBarra);
        }
    }

    public Rectangle getBounds(){
        return barra.getBounds();
    }
        
    public Rectangle getLimite(){
        return divisoria.getBounds();
    }

    public int getxBarra() {
        return xBarra;
    }

    public int getyBarra() {
        return yBarra;
    }
    
    
}


