package lluvia_de_estrellas;

import java.awt.Color;
import java.awt.Font;
import java.io.Serializable;
import javax.swing.JLabel;

public class Letra implements Serializable {

    private int widthVentana = 800;
    private static int HEIGHTPANEL = 50;
    private static int WIDTHPANEL = 50;
    private JLabel letra;
    private boolean direccion;
    private static int contadorLetras = 0;

    public Letra(String let) {

        crearLetra(let);
        direccion = true;
    }

    public void crearLetra(String let) {
        contadorLetras++;
        letra = new JLabel(let);
        letra.setLocation(posXAleatoria(), 0);
        letra.setFont(new Font("fuente", Font.TYPE1_FONT, 30));
        letra.setBounds(posXAleatoria(), 50, 30, 30);
    }

    //genera la posicion aleatoria
    public int posXAleatoria() {
        int x = (int) (Math.random() * widthVentana);
        return x;
    }

    //retorna la clase que se ha creado
    public Letra getThis() {
        return this;
    }

    //retorna el label creado
    public JLabel getLetra() {
        return letra;
    }

    public void cambiarDireccion() {
        direccion = false;
    }

    // Dirección de caida o subida que adoptan las letras
    public void mover(int pixeles) {
        if (direccion) {
            caer(pixeles);
        } else {
            subir(pixeles);
        }
    }

    public void caer(int pixelesMover) {
        letra.setLocation(letra.getX(), letra.getY() + pixelesMover);
    }

    public void subir(int pixelesMover) {
        letra.setLocation(letra.getX(), letra.getY() - pixelesMover);
    }

    public void cambiaColorLetra(int nivel) {
        switch (nivel) {
            case 1:
                letra.setForeground(Color.cyan);
                break;

            case 2:
                letra.setFont(new Font("fuente", Font.TYPE1_FONT, 15));
                letra.setForeground(Color.GREEN);
                System.out.println("Hola soy verde");
                break;

            case 3:
                letra.setForeground(Color.RED);
                break;

            case 4:
                letra.setForeground(Color.MAGENTA);
                break;

            case 5:
                letra.setForeground(Color.DARK_GRAY);
                break;


        }
    }

    @Override
    public String toString() {
        return "Letra{" + "widthVentana=" + widthVentana + ", letra=" + letra + '}';
    }


}
